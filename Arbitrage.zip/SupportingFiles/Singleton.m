

#import "Singleton.h"

@implementation Singleton
@synthesize dbPath,taskId,taskType,unitId,entryId,unitName;

+(Singleton*) sharedSingleton
{
	static Singleton* theInstance = nil;
	if (theInstance == nil)
	{
		theInstance = [[self alloc] init];
	}
	return theInstance;
}

// returns base url
- (NSString *) getBaseURL
{
    return @"http://programmingly.com/bvn/crypto/";
}
-(NSString *)getdbPath
{
    return self.dbPath;
}

-(NSString *)getTaskId
{
    return self.taskId;
}
-(NSString *)getTaskType
{
    return self.taskType;
}
-(NSString *)getUnitId
{
    return self.unitId;
}
-(NSString *)getEntryId
{
    return self.entryId;
}

-(NSString *)getUnitName
{
    return self.unitName;
}
@end
