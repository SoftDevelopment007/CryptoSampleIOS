

#import <Foundation/Foundation.h>

@interface Singleton : NSObject
{
    NSString *dbPath;
}
@property (nonatomic,retain) NSString *dbPath;
@property (nonatomic,retain) NSString *taskId;
@property (nonatomic,retain) NSString *taskType;
@property (nonatomic,retain) NSString *unitId;
@property (nonatomic,retain) NSString *entryId;
@property (nonatomic,retain) NSString *unitName;

+(Singleton*) sharedSingleton;
- (NSString *) getBaseURL;
-(NSString *)getdbPath;
-(NSString *)getTaskId;
-(NSString *)getTaskType;
-(NSString *)getUnitId;
-(NSString *)getEntryId;
-(NSString *)getUnitName;
@end
