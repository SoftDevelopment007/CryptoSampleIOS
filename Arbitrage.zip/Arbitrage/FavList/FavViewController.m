//
//  HomeViewController.m
//  Arbitrage
//
//  Created by Jignesh Patel on 22/02/18.
//  Copyright © 2018 Arbitrage. All rights reserved.
//

#import "FavViewController.h"
#import "ResultViewController.h"
#import "CustomCell.h"
#import "Singleton.h"
#import "StaticClass.h"
#import "Reachability.h"
#import "MBProgressHUD.h"
#import "UIView+Toast.h"

static NSInteger x;

@interface FavViewController ()
{
    IBOutlet UITableView *tableViewObj;
    
    IBOutlet UITextField *txtSearch;
    IBOutlet UILabel *lblNoData;
}
@property (nonatomic,retain)NSMutableArray *coinArray,*subCoinArray;
@end

@implementation FavViewController
@synthesize coinArray,subCoinArray;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
//    for (int i = 0; i<28;i++) {
//        NSString *str = [NSString stringWithFormat:@"%02d.png", i+1];
//        [coinArray addObject:str];
//    }
//    [tableViewObj reloadData];
    [txtSearch addTarget:self action:@selector(searchCoin) forControlEvents:UIControlEventEditingChanged];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];

    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSArray *arr = [userDefaults objectForKey:@"FAV"];
    coinArray = [[NSMutableArray alloc]initWithArray:arr];
    lblNoData.hidden = YES;
    if (coinArray.count == 0) {
        lblNoData.hidden = NO;
    }
    [tableViewObj reloadData];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSInteger noOfRecord = coinArray.count;
    NSInteger noOfpage=noOfRecord/4;
    NSInteger fractionPart=noOfRecord%4;
    NSInteger kNumberOfPages;
    if (fractionPart>0) {
        kNumberOfPages = noOfpage+1;
    }
    else {
        kNumberOfPages=noOfpage;
    }
    return kNumberOfPages;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    @try{
        static NSString *temp= @"CustomCell";
        CustomCell *cellheader = (CustomCell *)[tableViewObj dequeueReusableCellWithIdentifier:temp];
        cellheader.showsReorderControl = NO;
        cellheader.selectionStyle = UITableViewCellSelectionStyleNone;
        cellheader.backgroundColor=[UIColor clearColor];
        [cellheader.btn1 addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
        [cellheader.btn2 addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
        [cellheader.btn3 addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
        [cellheader.btn4 addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
        
        cellheader.btn1.tag = indexPath.row; cellheader.btn2.tag = indexPath.row;
        cellheader.btn3.tag = indexPath.row; cellheader.btn4.tag = indexPath.row;
        cellheader.btn1.hidden = YES;cellheader.btn2.hidden = YES;
        cellheader.btn3.hidden = YES;cellheader.btn4.hidden = YES;
        cellheader.img1.hidden = YES;cellheader.img2.hidden = YES;
        cellheader.img3.hidden = YES;cellheader.img4.hidden = YES;
        cellheader.img1.layer.cornerRadius = 25.0f;cellheader.img1.layer.masksToBounds = YES;
        cellheader.img2.layer.cornerRadius = 25.0f;cellheader.img2.layer.masksToBounds = YES;
        cellheader.img3.layer.cornerRadius = 25.0f;cellheader.img3.layer.masksToBounds = YES;
        cellheader.img4.layer.cornerRadius = 25.0f;cellheader.img4.layer.masksToBounds = YES;
        cellheader.img1.backgroundColor = [UIColor whiteColor];
        cellheader.img2.backgroundColor = [UIColor whiteColor];
        cellheader.img3.backgroundColor = [UIColor whiteColor];
        cellheader.img4.backgroundColor = [UIColor whiteColor];
        x = indexPath.row * 4;
        
        for (int i = 0; i<4; i++) {
            if (x<coinArray.count) {
                switch (i%4) {
                    case 0:
                    {
                        cellheader.btn1.hidden = NO;cellheader.img1.hidden = NO;
                        NSDictionary *tempObj = [coinArray objectAtIndex:x];
                        [cellheader.btn1 setTitle:[tempObj valueForKey:@"name"] forState:UIControlStateNormal];
                        cellheader.img1.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@.png",[tempObj valueForKey:@"symbol"]]];
                        cellheader.btn1.tag = x;
                        x = x+1;
                    }
                        break;
                    case 1:
                    {
                        cellheader.btn2.hidden = NO;cellheader.img2.hidden = NO;
                        NSDictionary *tempObj = [coinArray objectAtIndex:x];
                        [cellheader.btn2 setTitle:[tempObj valueForKey:@"name"] forState:UIControlStateNormal];
                        cellheader.img2.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@.png",[tempObj valueForKey:@"symbol"]]];
                        cellheader.btn2.tag = x;
                        x = x+1;
                    }
                        break;
                    case 2:
                    {
                        cellheader.btn3.hidden = NO;cellheader.img3.hidden = NO;
                        NSDictionary *tempObj = [coinArray objectAtIndex:x];
                        [cellheader.btn3 setTitle:[tempObj valueForKey:@"name"] forState:UIControlStateNormal];
                        cellheader.img3.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@.png",[tempObj valueForKey:@"symbol"]]];
                        cellheader.btn3.tag = x;
                        x = x+1;
                    }
                        break;
                    case 3:
                    {
                        cellheader.btn4.hidden = NO;cellheader.img4.hidden = NO;
                        NSDictionary *tempObj = [coinArray objectAtIndex:x];
                        [cellheader.btn4 setTitle:[tempObj valueForKey:@"name"] forState:UIControlStateNormal];
                        cellheader.img4.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@.png",[tempObj valueForKey:@"symbol"]]];
                        cellheader.btn4.tag = x;
                        x = x+1;
                    }
                        break;
                        
                    default:
                        break;
                }
            }
        }
        return cellheader;
        
    }
    @catch (NSException *exception) {
        
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 100.0f;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
}

-(IBAction)btnClick:(id)sender
{
    NSDictionary *tempObj = [coinArray objectAtIndex:[sender tag]];
    [StaticClass saveToUserDefaults:[tempObj valueForKey:@"symbol"] :@"C_ID"];
    ResultViewController *newView = [self.storyboard instantiateViewControllerWithIdentifier:@"RESULT"];
    //[newView setTypeStr:@"BTC"];
    [self.navigationController pushViewController:newView animated:YES];
}

-(void)searchCoin
{
    [self searchAutocompleteMenu:txtSearch.text];
}

-(void)searchAutocompleteMenu:(NSString *)substring
{
    @try {
        NSString *curString;
        
        [self.coinArray removeAllObjects];
        
        if(![substring isEqualToString:@""] )
        {
            for(NSDictionary *obj in  self.subCoinArray)
            {
                curString = [[obj valueForKey:@"MarketCurrencyLong"] stringByTrimmingCharactersInSet:
                             [NSCharacterSet whitespaceAndNewlineCharacterSet]];
                substring = [substring stringByTrimmingCharactersInSet:
                             [NSCharacterSet whitespaceAndNewlineCharacterSet]];
                
                NSRange substringRange = [curString rangeOfString:substring options:NSCaseInsensitiveSearch];
                if (substringRange.location != NSNotFound){
                    [self.coinArray addObject:obj];
                }
            }
        }
        else {
            for(NSDictionary *obj in  self.subCoinArray){
                [self.coinArray addObject:obj];
            }
        }
        [tableViewObj  reloadData];
    }
    @catch (NSException *exception) {
        
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (BOOL)textFieldShouldClear:(UITextField *)textField
{
    for(NSDictionary *obj in  subCoinArray){
        [coinArray addObject:obj];
    }
    [tableViewObj  reloadData];
    [textField resignFirstResponder];
    return YES;
}

-(IBAction)btnBackClick:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
