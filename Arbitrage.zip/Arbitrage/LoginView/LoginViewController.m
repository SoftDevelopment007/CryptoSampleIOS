//
//  ViewController.m
//  BelaStream
//
//  Created by Jignesh Patel on 30/01/18.
//  Copyright © 2018 BelaStream. All rights reserved.
//

#import "LoginViewController.h"
#import "Singleton.h"
#import "StaticClass.h"
#import "Reachability.h"
#import "MBProgressHUD.h"
#import "UIView+Toast.h"
#import "HomeViewController.h"
@interface LoginViewController ()
{
    IBOutlet UIButton *btnLogin;
}
@property (nonatomic,retain) IBOutlet UITextField *txtEmail,*txtPassword;
@end

@implementation LoginViewController
@synthesize txtEmail,txtPassword;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    btnLogin.layer.cornerRadius = 20.0f;
    btnLogin.layer.masksToBounds = YES;
    btnLogin.imageView.layer.cornerRadius = 7.0f;
    btnLogin.layer.shadowRadius = 3.5f;
    btnLogin.layer.shadowColor = [UIColor blackColor].CGColor;
    btnLogin.layer.shadowOffset = CGSizeMake(0.0f, 5.0f);
    btnLogin.layer.shadowOpacity = 0.5f;
    btnLogin.layer.masksToBounds = NO;
    
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = YES;
    //txtPassword.text = @"123";
    //txtEmail.text = @"j@j.com";
//    self.view.hidden = NO;
//    if([[StaticClass retrieveFromUserDefaults:@"UID"] integerValue] > 0){
//        self.view.hidden = YES;
//        HomeViewController *newView = [self.storyboard instantiateViewControllerWithIdentifier:@"HOME"];
//        [self.navigationController pushViewController:newView animated:YES];
//    }
}

//----------------------------------------LOGIN----------------------------------------------------------------//
-(IBAction)btnLoginClick:(id)sender
{
    [self dismissKeyboard];
    if([[txtEmail.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] isEqualToString:@""]){
        [self.view makeToast:@"Please enter you email"];
    }
    else if(![self validateEmail:txtEmail.text]){
        [self.view makeToast:@"Please enter valid email"];
    }
    else if([[txtPassword.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] isEqualToString:@""])
        [self.view makeToast:@"Pleaes etner your password"];
    else{
        
        Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
        NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
        if (networkStatus == NotReachable)
        {
            [self.view makeToast:@"Internet connection not available"];
        }
        else
        {
            [MBProgressHUD showHUDAddedTo:self.view animated:YES];
            NSString *strUrl=[NSString stringWithFormat:@"%@sign-in.php?email=%@&pass=%@&token=%@&key=2501145CC2D7E19D94EE7A29D8731E03",[[Singleton sharedSingleton]getBaseURL],txtEmail.text,txtPassword.text,@"NA"];
            NSURL *url=[NSURL URLWithString:strUrl];
            
            NSMutableURLRequest *rq = [NSMutableURLRequest requestWithURL:url];
            [rq setHTTPMethod:@"GET"];
            //[rq setHTTPMethod:@"POST"];
            //NSString *postString = [NSString stringWithFormat:@"func=auth;user=%@;pass=%@",txtEmail.text,txtPassword.text];
            //[rq setHTTPBody:[postString dataUsingEncoding:NSUTF8StringEncoding]];
            NSURLSession *session = [NSURLSession sharedSession];
            NSURLSessionDataTask *uploadTask = [session dataTaskWithRequest:rq
                                                          completionHandler:^(NSData *data, NSURLResponse *response, NSError *error)
                                                {
                                                    dispatch_async(dispatch_get_main_queue(), ^{
                                                        [MBProgressHUD hideHUDForView:self.view animated:YES];
                                                    });
                                                    if(!error){
                                                        NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                                                        dispatch_async(dispatch_get_main_queue(), ^{
                                                            if ([[dictionary valueForKey:@"data"] isEqualToString:@"success"]) {
                                                                NSDictionary *user_data = [dictionary valueForKey:@"user_data"];
                                                                [StaticClass saveToUserDefaults:[NSString stringWithFormat:@"%ld",[[user_data valueForKey:@"userID"]integerValue]] :@"UID"];
                                                                [StaticClass saveToUserDefaults:[user_data valueForKey:@"name"] :@"NAME"];
                                                                [StaticClass saveToUserDefaults:[user_data valueForKey:@"email"] :@"EMAIL"];
                                                                [StaticClass saveToUserDefaults:[user_data valueForKey:@"profile"] :@"PHOTO"];
                                                                HomeViewController *newView = [self.storyboard instantiateViewControllerWithIdentifier:@"HOME"];
                                                                [self.navigationController pushViewController:newView animated:YES];
                                                            }
                                                            else{
                                                                [MBProgressHUD hideHUDForView:self.view animated:YES];
                                                                [self.view makeToast:@"Email or Password in wrong"];
                                                            }
                                                        });
                                                    }
                                                    else {
                                                        dispatch_async(dispatch_get_main_queue(), ^{
                                                            [MBProgressHUD hideHUDForView:self.view animated:YES];
                                                        });
                                                    }
                                                }];
            [uploadTask resume];
        }
    }
}

//////Facebook Social Login Start//////////
-(IBAction)facebookLogin : (id) sender{
    FBSDKLoginManager *login = [[FBSDKLoginManager alloc] init];
    [StaticClass saveToUserDefaults:@"FB" :@"L_TYPE"];
    //  login.loginBehavior=FBSDKLoginBehaviorWeb;
    
    //[login logInWithReadPermissions:@[@"public_profile", @"email", @"user_friends"],fromViewController:self, handler:^(FBSDKLoginManagerLoginResult *result, NSError *error)  <===Deprecated
    //    login.loginBehavior = FBSDKShareDialogModeFeedWeb;
    
    [login logInWithReadPermissions:@[@"public_profile", @"email", @"user_friends"] fromViewController:self handler:^(FBSDKLoginManagerLoginResult *result, NSError *error)
     {
         if (error)
         {
             // Process error
             NSLog(@"error is :%@",error);
         }
         else if (result.isCancelled)
         {
             // Handle cancellations
             NSLog(@"error is :%@",error);
         }
         else
         {
             if ([result.grantedPermissions containsObject:@"email"])
             {
                 //NSString *fbAccessToken = [FBSDKAccessToken currentAccessToken].tokenString;
                 
                 NSLog(@"Login successfull");
                 [self fetchUserInfo];
                 [login logOut];
             }
         }
     }];
    
}

-(void)fetchUserInfo
{
    if ([FBSDKAccessToken currentAccessToken])
    {
        [[[FBSDKGraphRequest alloc] initWithGraphPath:@"me" parameters:@{@"fields": @"id,name,link,first_name, last_name, picture.type(large), email, birthday,friends,gender,age_range,cover"}]
         startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection, id result, NSError *error) {
             if (!error)
             {
                 Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
                 NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
                 if (networkStatus == NotReachable)
                 {
                     [self.view makeToast:@"Internet connection not available"];
                 }
                 else
                 {
//                     [Base64 initialize];
//                     NSString *imgStr = @"";
//                     if (self.myImageData != nil) {
//                         imgStr = [Base64 encode:self.myImageData];
//                     }
                     [MBProgressHUD showHUDAddedTo:self.view animated:YES];
                     NSString *strUrl=[NSString stringWithFormat:@"%@sign-up.php?",[[Singleton sharedSingleton]getBaseURL]];
                     NSURL *url=[NSURL URLWithString:strUrl];
                     
                     NSMutableURLRequest *rq = [NSMutableURLRequest requestWithURL:url];
                     
                     //[rq setHTTPMethod:@"GET"];
                     [rq setHTTPMethod:@"POST"];
                     NSString *postString = [NSString stringWithFormat:@"name=%@&email=%@&token=NA&fbid=%@&key=2501145CC2D7E19D94EE7A29D8731E03",[result valueForKey:@"name"],[result valueForKey:@"email"],[result valueForKey:@"id"]];
                     [rq setHTTPBody:[postString dataUsingEncoding:NSUTF8StringEncoding]];
                     NSURLSession *session = [NSURLSession sharedSession];
                     NSURLSessionDataTask *uploadTask = [session dataTaskWithRequest:rq
                                                                   completionHandler:^(NSData *data, NSURLResponse *response, NSError *error)
                                                         {
                                                             dispatch_async(dispatch_get_main_queue(), ^{
                                                                 [MBProgressHUD hideHUDForView:self.view animated:YES];
                                                             });
                                                             if(!error){
                                                                 NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                                                                 dispatch_async(dispatch_get_main_queue(), ^{
                                                                     if ([[dictionary valueForKey:@"data"] isEqualToString:@"success"]) {
                                                                         NSDictionary *user_data = [dictionary valueForKey:@"user_data"];
                                                                         [StaticClass saveToUserDefaults:[user_data valueForKey:@"userID"] :@"UID"];
                                                                         [StaticClass saveToUserDefaults:[user_data valueForKey:@"name"] :@"NAME"];
                                                                         
                                                                         HomeViewController *newView = [self.storyboard instantiateViewControllerWithIdentifier:@"HOME"];
                                                                         [self.navigationController pushViewController:newView animated:YES];
                                                                     }
                                                                     else{
                                                                         [MBProgressHUD hideHUDForView:self.view animated:YES];
                                                                         [self.view makeToast:@"Email or Password in wrong"];
                                                                     }
                                                                 });
                                                             }
                                                             else {
                                                                 dispatch_async(dispatch_get_main_queue(), ^{
                                                                     [MBProgressHUD hideHUDForView:self.view animated:YES];
                                                                 });
                                                             }
                                                         }];
                     [uploadTask resume];
                 }
             }
         }];
    }
}
-(void)dismissKeyboard
{
    [txtEmail resignFirstResponder]; [txtPassword resignFirstResponder];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

-(BOOL)validateEmail:(NSString *)candidate {
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    
    return [emailTest evaluateWithObject:candidate];
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField
{
    return YES;
}

-(IBAction)btnBackClick:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];// this will do the trick
    [super touchesBegan:touches withEvent:event];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
