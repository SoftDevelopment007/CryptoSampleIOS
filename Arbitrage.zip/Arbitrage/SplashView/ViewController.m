//
//  ViewController.m
//  Arbitrage
//
//  Created by Jignesh Patel on 22/02/18.
//  Copyright © 2018 Arbitrage. All rights reserved.
//

#import "ViewController.h"
#import "StaticClass.h"
#import "HomeViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.navigationController.navigationBarHidden = YES;
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = YES;
    //txtPassword.text = @"123";
    //txtEmail.text = @"j@j.com";
    self.view.hidden = NO;
    if([[StaticClass retrieveFromUserDefaults:@"UID"] integerValue] > 0){
        self.view.hidden = YES;
        HomeViewController *newView = [self.storyboard instantiateViewControllerWithIdentifier:@"HOME"];
        [self.navigationController pushViewController:newView animated:YES];
    }
}

-(IBAction)btnSkipClick:(id)sender
{
    HomeViewController *newView = [self.storyboard instantiateViewControllerWithIdentifier:@"HOME"];
    [self.navigationController pushViewController:newView animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
