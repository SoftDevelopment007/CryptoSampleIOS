//
//  ResultViewController.m
//  Arbitrage
//
//  Created by Jignesh Patel on 22/02/18.
//  Copyright © 2018 Arbitrage. All rights reserved.
//

#import "ResultViewController.h"
#import "Singleton.h"
#import "StaticClass.h"
#import "Reachability.h"
#import "MBProgressHUD.h"
#import "UIView+Toast.h"

static NSInteger count,typeIndex;
static float price1,price2;

@interface ResultViewController ()
{
    IBOutlet UILabel *lblCompare1,*lblCompare2,*lblPrice1,*lblPrice2,*lblDiff;
    IBOutlet UIButton *btnCoinspot,*btnBinance,*btnCoinbase,*btnBittrex,*btnHitbtc,*btnBuy,*btnSell,*btnCryptopia,*btnLiqui,*btnGdax;
    NSMutableArray *dataArray;
    NSTimer *timerObj;
}
@end

@implementation ResultViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    timerObj = [NSTimer scheduledTimerWithTimeInterval:12.0 target:self selector:@selector(hideProgress) userInfo:nil repeats:YES];
}

-(void)hideProgress
{
    [MBProgressHUD hideHUDForView:self.view animated:YES];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = YES;
    [btnCoinspot setImage:[UIImage imageNamed:@"unCheck.png"] forState:UIControlStateNormal];
    [btnBinance setImage:[UIImage imageNamed:@"unCheck.png"] forState:UIControlStateNormal];
    [btnCoinbase setImage:[UIImage imageNamed:@"unCheck.png"] forState:UIControlStateNormal];
    [btnBittrex setImage:[UIImage imageNamed:@"unCheck.png"] forState:UIControlStateNormal];
    [btnHitbtc setImage:[UIImage imageNamed:@"unCheck.png"] forState:UIControlStateNormal];
    [btnGdax setImage:[UIImage imageNamed:@"unCheck.png"] forState:UIControlStateNormal];
    [btnLiqui setImage:[UIImage imageNamed:@"unCheck.png"] forState:UIControlStateNormal];
    [btnCryptopia setImage:[UIImage imageNamed:@"unCheck.png"] forState:UIControlStateNormal];

    lblDiff.text = @""; lblPrice1.text = @"";lblPrice2.text = @""; lblCompare1.text = @"";lblCompare2.text = @"";
    count = 0;
    dataArray = [[NSMutableArray alloc]init];
    [btnBuy setImage:[UIImage imageNamed:@"check.png"] forState:UIControlStateNormal];
    [btnSell setImage:[UIImage imageNamed:@"unCheck.png"] forState:UIControlStateNormal];
    typeIndex = 1;
    [self getBTCUSD];
}

-(IBAction)btnBuyClick:(id)sender
{
    [btnBuy setImage:[UIImage imageNamed:@"check.png"] forState:UIControlStateNormal];
    [btnSell setImage:[UIImage imageNamed:@"unCheck.png"] forState:UIControlStateNormal];
    typeIndex = 1;
    [self setLabelPrice];
}

-(IBAction)btnSellClick:(id)sender
{
    [btnBuy setImage:[UIImage imageNamed:@"unCheck.png"] forState:UIControlStateNormal];
    [btnSell setImage:[UIImage imageNamed:@"check.png"] forState:UIControlStateNormal];
    typeIndex = 2;
    [self setLabelPrice];
}

-(IBAction)btnCoinspotClick:(id)sender
{
    if ([dataArray containsObject:@"Coinspot"]) {
        [btnCoinspot setImage:[UIImage imageNamed:@"unCheck.png"] forState:UIControlStateNormal];
        [dataArray removeObjectIdenticalTo:@"Coinspot"];
    }
    else{
        [btnCoinspot setImage:[UIImage imageNamed:@"check.png"] forState:UIControlStateNormal];
        [dataArray addObject:@"Coinspot"];
    }
    [self setLabelPrice];
}

-(IBAction)btnBinanceClick:(id)sender
{
    if ([dataArray containsObject:@"Binance"]) {
        [btnBinance setImage:[UIImage imageNamed:@"unCheck.png"] forState:UIControlStateNormal];
        [dataArray removeObjectIdenticalTo:@"Binance"];
    }
    else{
        [btnBinance setImage:[UIImage imageNamed:@"check.png"] forState:UIControlStateNormal];
        [dataArray addObject:@"Binance"];
    }
    [self setLabelPrice];
}

-(IBAction)btnCoinbaseClick:(id)sender
{
    if ([dataArray containsObject:@"Coinbase"]) {
        [btnCoinbase setImage:[UIImage imageNamed:@"unCheck.png"] forState:UIControlStateNormal];
        [dataArray removeObjectIdenticalTo:@"Coinbase"];
    }
    else{
        [btnCoinbase setImage:[UIImage imageNamed:@"check.png"] forState:UIControlStateNormal];
        [dataArray addObject:@"Coinbase"];
    }
    [self setLabelPrice];
}

-(IBAction)btnBittrexClick:(id)sender
{
    if ([dataArray containsObject:@"Bittrex"]) {
        [btnBittrex setImage:[UIImage imageNamed:@"unCheck.png"] forState:UIControlStateNormal];
        [dataArray removeObjectIdenticalTo:@"Bittrex"];
    }
    else{
        [btnBittrex setImage:[UIImage imageNamed:@"check.png"] forState:UIControlStateNormal];
        [dataArray addObject:@"Bittrex"];
    }
    [self setLabelPrice];
}

-(IBAction)btnHitbtcClick:(id)sender
{
    if ([dataArray containsObject:@"Hitbtc"]) {
        [btnHitbtc setImage:[UIImage imageNamed:@"unCheck.png"] forState:UIControlStateNormal];
        [dataArray removeObjectIdenticalTo:@"Hitbtc"];
    }
    else{
        [btnHitbtc setImage:[UIImage imageNamed:@"check.png"] forState:UIControlStateNormal];
        [dataArray addObject:@"Hitbtc"];
    }
    [self setLabelPrice];
}

-(IBAction)btnCryptopiaClick:(id)sender
{
    if ([dataArray containsObject:@"Cryptopia"]) {
        [btnCryptopia setImage:[UIImage imageNamed:@"unCheck.png"] forState:UIControlStateNormal];
        [dataArray removeObjectIdenticalTo:@"Cryptopia"];
    }
    else{
        [btnCryptopia setImage:[UIImage imageNamed:@"check.png"] forState:UIControlStateNormal];
        [dataArray addObject:@"Cryptopia"];
    }
    [self setLabelPrice];
}

-(IBAction)btnLiquiClick:(id)sender
{
    if ([dataArray containsObject:@"Liqui"]) {
        [btnLiqui setImage:[UIImage imageNamed:@"unCheck.png"] forState:UIControlStateNormal];
        [dataArray removeObjectIdenticalTo:@"Liqui"];
    }
    else{
        [btnLiqui setImage:[UIImage imageNamed:@"check.png"] forState:UIControlStateNormal];
        [dataArray addObject:@"Liqui"];
    }
    [self setLabelPrice];
}

-(IBAction)btnGdaxClick:(id)sender
{
    if ([dataArray containsObject:@"Gdax"]) {
        [btnGdax setImage:[UIImage imageNamed:@"unCheck.png"] forState:UIControlStateNormal];
        [dataArray removeObjectIdenticalTo:@"Gdax"];
    }
    else{
        [btnGdax setImage:[UIImage imageNamed:@"check.png"] forState:UIControlStateNormal];
        [dataArray addObject:@"Gdax"];
    }
    [self setLabelPrice];
}


-(void)setLabelPrice
{
    if (dataArray.count > 2) {
        if ([[dataArray firstObject] isEqualToString:@"Coinspot"]) {
            [btnCoinspot setImage:[UIImage imageNamed:@"unCheck.png"] forState:UIControlStateNormal];
        }
        if ([[dataArray firstObject] isEqualToString:@"Binance"]) {
            [btnBinance setImage:[UIImage imageNamed:@"unCheck.png"] forState:UIControlStateNormal];
        }
        if ([[dataArray firstObject] isEqualToString:@"Coinbase"]) {
            [btnCoinbase setImage:[UIImage imageNamed:@"unCheck.png"] forState:UIControlStateNormal];
        }
        if ([[dataArray firstObject] isEqualToString:@"Bittrex"]) {
            [btnBittrex setImage:[UIImage imageNamed:@"unCheck.png"] forState:UIControlStateNormal];
        }
        if ([[dataArray firstObject] isEqualToString:@"Hitbtc"]) {
            [btnHitbtc setImage:[UIImage imageNamed:@"unCheck.png"] forState:UIControlStateNormal];
        }
        if ([[dataArray firstObject] isEqualToString:@"Cryptopia"]) {
            [btnCryptopia setImage:[UIImage imageNamed:@"unCheck.png"] forState:UIControlStateNormal];
        }
        if ([[dataArray firstObject] isEqualToString:@"Liqui"]) {
            [btnLiqui setImage:[UIImage imageNamed:@"unCheck.png"] forState:UIControlStateNormal];
        }
        if ([[dataArray firstObject] isEqualToString:@"Gdax"]) {
            [btnGdax setImage:[UIImage imageNamed:@"unCheck.png"] forState:UIControlStateNormal];
        }
        [dataArray removeObjectAtIndex:0];
    }
//    for (int i = 0; i<dataArray.count; i++) {
//        if (i==0) {
//            lblCompare1.text = [dataArray objectAtIndex:i];
//            [self setFirstExchangeValue:[dataArray objectAtIndex:i]];
//        }
//        if (i==1) {
//            lblCompare2.text = [dataArray objectAtIndex:i];
//            [self setSecondExchangeValue:[dataArray objectAtIndex:i]];
//        }
//    }
    if (dataArray.count > 0) {
        lblCompare1.text = [dataArray objectAtIndex:0];
        [self setFirstExchangeValue:[dataArray objectAtIndex:0]];
    }
}

-(void)setFirstExchangeValue:(NSString *)str
{
    lblPrice1.text = @"0.00 USD";
    Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
    if (networkStatus == NotReachable)
    {
        [self.view makeToast:@"Internet connection not available"];
    }
    else
    {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        NSString *strUrl;
        if ([str isEqualToString:@"Coinspot"]) {
            strUrl =[NSString stringWithFormat:@"https://www.coinspot.com.au/pubapi/latest"];
        }
        else if ([str isEqualToString:@"Bittrex"]) {
            if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                strUrl =[NSString stringWithFormat:@"https://bittrex.com/api/v1.1/public/getticker?market=USDT-%@",[StaticClass retrieveFromUserDefaults:@"C_ID"]];
            }
            else{
                strUrl =[NSString stringWithFormat:@"https://bittrex.com/api/v1.1/public/getticker?market=BTC-%@",[StaticClass retrieveFromUserDefaults:@"C_ID"]];
            }
        }
        else if ([str isEqualToString:@"Coinbase"]) {
            if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                strUrl =[NSString stringWithFormat:@"https://api.gdax.com/products/%@-USD/ticker",[StaticClass retrieveFromUserDefaults:@"C_ID"]];
            }
            else{
                strUrl =[NSString stringWithFormat:@"https://api.gdax.com/products/%@-BTC/ticker",[StaticClass retrieveFromUserDefaults:@"C_ID"]];
            }
        }
        else if ([str isEqualToString:@"Hitbtc"]) {
            if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                strUrl =[NSString stringWithFormat:@"https://apiv2.bitcoinaverage.com/exchanges/ticker/hitbtc/%@USD",[StaticClass retrieveFromUserDefaults:@"C_ID"]];
            }
            else{
                strUrl =[NSString stringWithFormat:@"https://apiv2.bitcoinaverage.com/exchanges/ticker/hitbtc/%@BTC",[StaticClass retrieveFromUserDefaults:@"C_ID"]];

            }
        }
        else if ([str isEqualToString:@"Cryptopia"]) {
            if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                strUrl =[NSString stringWithFormat:@"https://www.cryptopia.co.nz/api/GetMarket/%@_USDT",[StaticClass retrieveFromUserDefaults:@"C_ID"]];
            }
            else{
                strUrl =[NSString stringWithFormat:@"https://www.cryptopia.co.nz/api/GetMarket/%@_BTC",[StaticClass retrieveFromUserDefaults:@"C_ID"]];
            }
        }
        else if ([str isEqualToString:@"Liqui"]) {
            if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                strUrl =[NSString stringWithFormat:@"https://api.liqui.io/api/3/ticker/%@_usdt",[[StaticClass retrieveFromUserDefaults:@"C_ID"]lowercaseString]];
            }
            else{
                strUrl =[NSString stringWithFormat:@"https://api.liqui.io/api/3/ticker/%@_btc",[[StaticClass retrieveFromUserDefaults:@"C_ID"]lowercaseString]];
            }
        }
        else if ([str isEqualToString:@"Gdax"]) {
                strUrl =[NSString stringWithFormat:@"https://api.gdax.com/products/%@-USD/ticker",[StaticClass retrieveFromUserDefaults:@"C_ID"]];
        }
        else{
            if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                strUrl =[NSString stringWithFormat:@"https://api.binance.com/api/v3/ticker/bookTicker?symbol=%@USDT",[StaticClass retrieveFromUserDefaults:@"C_ID"]];
            }
            else{
                strUrl =[NSString stringWithFormat:@"https://api.binance.com/api/v3/ticker/bookTicker?symbol=%@BTC",[StaticClass retrieveFromUserDefaults:@"C_ID"]];
            }
        }
        NSURL *url=[NSURL URLWithString:[strUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
        
        NSMutableURLRequest *rq = [NSMutableURLRequest requestWithURL:url];
        [rq setHTTPMethod:@"GET"];
        //[rq setHTTPMethod:@"POST"];
        //NSString *postString = [NSString stringWithFormat:@"func=auth;user=%@;pass=%@",txtEmail.text,txtPassword.text];
        //[rq setHTTPBody:[postString dataUsingEncoding:NSUTF8StringEncoding]];
        NSURLSession *session = [NSURLSession sharedSession];
        NSURLSessionDataTask *uploadTask = [session dataTaskWithRequest:rq
                                                      completionHandler:^(NSData *data, NSURLResponse *response, NSError *error)
                                            {
                                                if(!error){
                                                    dispatch_async(dispatch_get_main_queue(), ^{
                                                        [MBProgressHUD hideHUDForView:self.view animated:YES];
                                                    });
                                                    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                                                    dispatch_async(dispatch_get_main_queue(), ^{
                                                        if ([str isEqualToString:@"Binance"]) {
                                                            if (dictionary.count > 0) {
                                                                if (typeIndex == 1) {
                                                                    float bid = 0.0;
                                                                    if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                                                                        bid = [[dictionary valueForKey:@"bidPrice"]floatValue];
                                                                    }
                                                                    else{
                                                                        bid = [[StaticClass retrieveFromUserDefaults:@"BTCUSD"] floatValue]*[[dictionary valueForKey:@"bidPrice"]floatValue];
                                                                    }
                                                                    lblPrice1.text = [NSString stringWithFormat:@"%.2f USD",bid];
                                                                    price1 =  bid;
                                                                }
                                                                else{
                                                                    float ask = 0.0;
                                                                    if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                                                                        ask = [[dictionary valueForKey:@"askPrice"]floatValue];
                                                                    }
                                                                    else{
                                                                        ask = [[StaticClass retrieveFromUserDefaults:@"BTCUSD"] floatValue]*[[dictionary valueForKey:@"askPrice"]floatValue];
                                                                    }
                                                                    
                                                                    lblPrice1.text = [NSString stringWithFormat:@"%.2f USD",ask];
                                                                    price1 = ask;
                                                                }
                                                            }
                                                        }
                                                        else if ([str isEqualToString:@"Coinspot"]) {
                                                            if ([[dictionary valueForKey:@"status"] isEqualToString:@"ok"]) {
                                                                NSDictionary *price = [dictionary valueForKey:@"prices"];
                                                                for (int i = 0; i<price.count;i++) {
                                                                    NSString *strName = [[price allKeys]objectAtIndex:i];
                                                                    if ([strName isEqualToString:[[StaticClass retrieveFromUserDefaults:@"C_ID"]lowercaseString]]) {
                                                                        NSDictionary *dict = [price valueForKey:[[StaticClass retrieveFromUserDefaults:@"C_ID"] lowercaseString]];
                                                                        if (typeIndex == 1) {
                                                                            lblPrice1.text = [NSString stringWithFormat:@"%.2f USD",[[dict valueForKey:@"bid"]floatValue]];
                                                                            price1 =  [[dict valueForKey:@"bid"]floatValue];
                                                                        }
                                                                        else{
                                                                            lblPrice1.text = [NSString stringWithFormat:@"%.2f USD",[[dict valueForKey:@"ask"]floatValue]];
                                                                            price1 =  [[dict valueForKey:@"ask"]floatValue];
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        else if ([str isEqualToString:@"Bittrex"]) {
                                                            if ([[dictionary valueForKey:@"success"] integerValue] == 1) {
                                                                NSDictionary *result = [dictionary valueForKey:@"result"];
                                                                if (typeIndex == 1) {
                                                                    float bid = 0.0;
                                                                    if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                                                                        bid = [[result valueForKey:@"Bid"]floatValue];
                                                                    }
                                                                    else{
                                                                        bid = [[StaticClass retrieveFromUserDefaults:@"BTCUSD"] floatValue]*[[result valueForKey:@"Bid"]floatValue];
                                                                    }
                                                                    lblPrice1.text = [NSString stringWithFormat:@"%.2f USD",bid];
                                                                    price1 =  bid;
                                                                }
                                                                else{
                                                                    float ask = 0.0;
                                                                    if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                                                                        ask = [[result valueForKey:@"Ask"]floatValue];
                                                                    }
                                                                    else{
                                                                        ask = [[StaticClass retrieveFromUserDefaults:@"BTCUSD"] floatValue]*[[result valueForKey:@"Ask"]floatValue];
                                                                    }

                                                                    lblPrice1.text = [NSString stringWithFormat:@"%.2f USD",ask];
                                                                    price1 = ask;
                                                                }
                                                            }
                                                        }
                                                        else if ([str isEqualToString:@"Hitbtc"]) {
                                                            if (typeIndex == 1) {
                                                                float bid = 0.0;
                                                                if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                                                                    bid = [[dictionary valueForKey:@"bid"]floatValue];
                                                                }
                                                                else{
                                                                    bid = [[StaticClass retrieveFromUserDefaults:@"BTCUSD"] floatValue]*[[dictionary valueForKey:@"bid"]floatValue];
                                                                }

                                                                lblPrice1.text = [NSString stringWithFormat:@"%.2f USD",bid];
                                                                price1 =  bid;//[[dictionary valueForKey:@"bid"]floatValue];
                                                            }
                                                            else{
                                                                float ask = 0.0;
                                                                if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                                                                    ask = [[dictionary valueForKey:@"ask"]floatValue];
                                                                }
                                                                else{
                                                                    ask = [[StaticClass retrieveFromUserDefaults:@"BTCUSD"] floatValue]*[[dictionary valueForKey:@"ask"]floatValue];
                                                                }

                                                                lblPrice1.text = [NSString stringWithFormat:@"%.2f USD",ask];
                                                                price1 =  ask;//[[dictionary valueForKey:@"ask"]floatValue];
                                                            }
                                                        }
                                                        else if ([str isEqualToString:@"Cryptopia"]) {
                                                            if ([[dictionary valueForKey:@"Success"] boolValue] == true) {
                                                                NSDictionary *data = [dictionary valueForKey:@"Data"];
                                                                if (data != (id)[NSNull null]) {
                                                                    if (typeIndex == 1) {
                                                                        float bid = 0.0;
                                                                        if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                                                                            bid = [[data valueForKey:@"BidPrice"]floatValue];
                                                                            lblPrice1.text = [NSString stringWithFormat:@"%.2f USD",bid];
                                                                            price1 =  bid;//[[dictionary valueForKey:@"bid"]floatValue];
                                                                        }
                                                                        else{
                                                                            bid = [[data valueForKey:@"BidPrice"]floatValue]* [[StaticClass retrieveFromUserDefaults:@"BTCUSD"] floatValue];
                                                                            lblPrice1.text = [NSString stringWithFormat:@"%.2f USD",bid];
                                                                            price1 =  bid;//[[dictionary valueForKey:@"bid"]floatValue];
                                                                            
                                                                        }
                                                                    }
                                                                    else{
                                                                        float ask = 0.0;
                                                                        if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                                                                            ask = [[data valueForKey:@"AskPrice"]floatValue];
                                                                            lblPrice1.text = [NSString stringWithFormat:@"%.2f USD",ask];
                                                                            price1 =  ask;//[[dictionary valueForKey:@"bid"]floatValue];
                                                                            
                                                                        }
                                                                        else{
                                                                            ask = [[data valueForKey:@"AskPrice"]floatValue]* [[StaticClass retrieveFromUserDefaults:@"BTCUSD"] floatValue];
                                                                            lblPrice1.text = [NSString stringWithFormat:@"%.2f USD",ask];
                                                                            price1 =  ask;//[[dictionary valueForKey:@"bid"]floatValue];
                                                                            
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        else if ([str isEqualToString:@"Liqui"]) {
                                                            NSString *str = @"";
                                                            if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                                                                str = @"btc_usdt";
                                                            }
                                                            else{
                                                                str = [NSString stringWithFormat:@"%@_btc",[[StaticClass retrieveFromUserDefaults:@"C_ID"]lowercaseString]];
                                                            }
                                                            NSDictionary *result = [dictionary valueForKey:str];
                                                            if (typeIndex == 1) {
                                                                float bid = 0.0;
                                                                if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                                                                    bid = [[result valueForKey:@"buy"]floatValue];
                                                                }
                                                                else{
                                                                    bid = [[StaticClass retrieveFromUserDefaults:@"BTCUSD"] floatValue]*[[result valueForKey:@"buy"]floatValue];
                                                                }
                                                                lblPrice1.text = [NSString stringWithFormat:@"%.2f USD",bid];
                                                                price1 =  bid;
                                                            }
                                                            else{
                                                                float ask = 0.0;
                                                                if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                                                                    ask = [[result valueForKey:@"sell"]floatValue];
                                                                }
                                                                else{
                                                                    ask = [[StaticClass retrieveFromUserDefaults:@"BTCUSD"] floatValue]*[[result valueForKey:@"sell"]floatValue];
                                                                }
                                                                lblPrice1.text = [NSString stringWithFormat:@"%.2f USD",ask];
                                                                price1 = ask;
                                                            }
                                                        }
                                                        else if ([str isEqualToString:@"Gdax"]) {
                                                            if (typeIndex == 1) {
                                                                float bid = 0.0;
                                                                bid = [[dictionary valueForKey:@"bid"]floatValue];
                                                                lblPrice1.text = [NSString stringWithFormat:@"%.2f USD",bid];
                                                                price1 =  bid;//[[dictionary valueForKey:@"bid"]floatValue];
                                                            }
                                                            else{
                                                                float ask = 0.0;
                                                                ask = [[dictionary valueForKey:@"ask"]floatValue];
                                                                lblPrice1.text = [NSString stringWithFormat:@"%.2f USD",ask];
                                                                price1 =  ask;//[[dictionary valueForKey:@"bid"]floatValue];
                                                            }
                                                        }
                                                        else if ([str isEqualToString:@"Coinbase"]) {
                                                            if (typeIndex == 1) {
                                                                if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                                                                    lblPrice1.text = [NSString stringWithFormat:@"%.2f USD",[[dictionary valueForKey:@"bid"]floatValue]];
                                                                    price1 =  [[dictionary valueForKey:@"bid"]floatValue];
                                                                }
                                                                else{
                                                                    float bid = [[StaticClass retrieveFromUserDefaults:@"BTCUSD"] floatValue]*[[dictionary valueForKey:@"bid"]floatValue];

                                                                    lblPrice1.text = [NSString stringWithFormat:@"%.2f USD",bid];
                                                                    price1 = bid;

                                                                }
                                                            }
                                                            else{
                                                                if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                                                                    lblPrice1.text = [NSString stringWithFormat:@"%.2f USD",[[dictionary valueForKey:@"ask"]floatValue]];
                                                                    price1 =  [[dictionary valueForKey:@"ask"]floatValue];
                                                                }
                                                                else{
                                                                    float ask = [[StaticClass retrieveFromUserDefaults:@"BTCUSD"] floatValue]*[[dictionary valueForKey:@"ask"]floatValue];
                                                                    
                                                                    lblPrice1.text = [NSString stringWithFormat:@"%.2f USD",ask];
                                                                    price1 = ask;
                                                                }
                                                            }
                                                        }
                                                        else{
                                                            if ([[dictionary valueForKey:@"success"] integerValue] == 1) {
                                                                NSDictionary *result = [dictionary valueForKey:@"result"];
                                                                if (typeIndex == 1) {
                                                                    lblPrice1.text = [NSString stringWithFormat:@"%.2f USD",[[result valueForKey:@"Bid"]floatValue]];
                                                                    price1 =  [[result valueForKey:@"Bid"]floatValue];
                                                                }
                                                                else{
                                                                    lblPrice1.text = [NSString stringWithFormat:@"%.2f USD",[[result valueForKey:@"Ask"]floatValue]];
                                                                    price1 =  [[result valueForKey:@"Ask"]floatValue];
                                                                }
                                                            }
                                                            else{
                                                                if (typeIndex == 1) {
                                                                    lblPrice1.text = [NSString stringWithFormat:@"%.2f USD",[[dictionary valueForKey:@"bid"]floatValue]];
                                                                    price1 =  [[dictionary valueForKey:@"bid"]floatValue];
                                                                }
                                                                else{
                                                                    lblPrice1.text = [NSString stringWithFormat:@"%.2f USD",[[dictionary valueForKey:@"ask"]floatValue]];
                                                                    price1 =  [[dictionary valueForKey:@"ask"]floatValue];
                                                                }
                                                            }
                                                            if (dataArray.count > 1) {
                                                                lblCompare2.text = [dataArray objectAtIndex:1];
                                                                [self setSecondExchangeValue:[dataArray objectAtIndex:1]];
                                                            }
                                                        }
                                                        if (dataArray.count >1) {
                                                            lblCompare2.text = [dataArray objectAtIndex:1];
                                                            [self setSecondExchangeValue:[dataArray objectAtIndex:1]];
                                                        }
                                                    });
                                                }
                                                else {
                                                    dispatch_async(dispatch_get_main_queue(), ^{
                                                        [MBProgressHUD hideHUDForView:self.view animated:YES];
                                                    });
                                                }
                                            }];
        [uploadTask resume];
    }
}

-(void)setSecondExchangeValue:(NSString *)str
{
    lblPrice2.text = @"0.00 USD";
    Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
    if (networkStatus == NotReachable)
    {
        [self.view makeToast:@"Internet connection not available"];
    }
    else
    {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        NSString *strUrl;
        if ([str isEqualToString:@"Coinspot"]) {
            strUrl =[NSString stringWithFormat:@"https://www.coinspot.com.au/pubapi/latest"];
        }
        else if ([str isEqualToString:@"Bittrex"]) {
            if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                strUrl =[NSString stringWithFormat:@"https://bittrex.com/api/v1.1/public/getticker?market=USDT-%@",[StaticClass retrieveFromUserDefaults:@"C_ID"]];
            }
            else{
                strUrl =[NSString stringWithFormat:@"https://bittrex.com/api/v1.1/public/getticker?market=BTC-%@",[StaticClass retrieveFromUserDefaults:@"C_ID"]];
            }
        }
        else if ([str isEqualToString:@"Coinbase"]) {
            if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                strUrl =[NSString stringWithFormat:@"https://api.gdax.com/products/%@-USD/ticker",[StaticClass retrieveFromUserDefaults:@"C_ID"]];
            }
            else{
                strUrl =[NSString stringWithFormat:@"https://api.gdax.com/products/%@-BTC/ticker",[StaticClass retrieveFromUserDefaults:@"C_ID"]];
            }
        }
        else if ([str isEqualToString:@"Hitbtc"]) {
            if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                strUrl =[NSString stringWithFormat:@"https://apiv2.bitcoinaverage.com/exchanges/ticker/hitbtc/%@USD",[StaticClass retrieveFromUserDefaults:@"C_ID"]];
                
            }
            else{
                
                strUrl =[NSString stringWithFormat:@"https://apiv2.bitcoinaverage.com/exchanges/ticker/hitbtc/%@BTC",[StaticClass retrieveFromUserDefaults:@"C_ID"]];
            }
        }
        else if ([str isEqualToString:@"Cryptopia"]) {
            if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                strUrl =[NSString stringWithFormat:@"https://www.cryptopia.co.nz/api/GetMarket/%@_USDT",[StaticClass retrieveFromUserDefaults:@"C_ID"]];
            }
            else{
                strUrl =[NSString stringWithFormat:@"https://www.cryptopia.co.nz/api/GetMarket/%@_BTC",[StaticClass retrieveFromUserDefaults:@"C_ID"]];
            }
        }
        else if ([str isEqualToString:@"Liqui"]) {
            if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                strUrl =[NSString stringWithFormat:@"https://api.liqui.io/api/3/ticker/%@_usdt",[[StaticClass retrieveFromUserDefaults:@"C_ID"]lowercaseString]];
            }
            else{
                strUrl =[NSString stringWithFormat:@"https://api.liqui.io/api/3/ticker/%@_btc",[[StaticClass retrieveFromUserDefaults:@"C_ID"]lowercaseString]];
            }
        }
        else if ([str isEqualToString:@"Gdax"]) {
            strUrl =[NSString stringWithFormat:@"https://api.gdax.com/products/%@-USD/ticker",[StaticClass retrieveFromUserDefaults:@"C_ID"]];
        }
        else{
            if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                strUrl =[NSString stringWithFormat:@"https://api.binance.com/api/v3/ticker/bookTicker?symbol=%@USDT",[StaticClass retrieveFromUserDefaults:@"C_ID"]];
            }
            else{
                strUrl =[NSString stringWithFormat:@"https://api.binance.com/api/v3/ticker/bookTicker?symbol=%@BTC",[StaticClass retrieveFromUserDefaults:@"C_ID"]];
            }
        }
        NSURL *url=[NSURL URLWithString:[strUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
        
        NSMutableURLRequest *rq = [NSMutableURLRequest requestWithURL:url];
        [rq setHTTPMethod:@"GET"];
        //[rq setHTTPMethod:@"POST"];
        //NSString *postString = [NSString stringWithFormat:@"func=auth;user=%@;pass=%@",txtEmail.text,txtPassword.text];
        //[rq setHTTPBody:[postString dataUsingEncoding:NSUTF8StringEncoding]];
        NSURLSession *session = [NSURLSession sharedSession];
        NSURLSessionDataTask *uploadTask = [session dataTaskWithRequest:rq
                                                      completionHandler:^(NSData *data, NSURLResponse *response, NSError *error)
                                            {
                                                dispatch_async(dispatch_get_main_queue(), ^{
                                                    [MBProgressHUD hideHUDForView:self.view animated:YES];
                                                });
                                                if(!error){
                                                    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                                                    dispatch_async(dispatch_get_main_queue(), ^{
                                                        if ([str isEqualToString:@"Binance"]) {
                                                            if (dictionary.count > 0) {
                                                                if (typeIndex == 1) {
                                                                    float bid = 0.0;
                                                                    if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                                                                        bid = [[dictionary valueForKey:@"bidPrice"]floatValue];
                                                                    }
                                                                    else{
                                                                        bid = [[StaticClass retrieveFromUserDefaults:@"BTCUSD"] floatValue]*[[dictionary valueForKey:@"bidPrice"]floatValue];
                                                                    }
                                                                    lblPrice2.text = [NSString stringWithFormat:@"%.2f USD",bid];
                                                                    price2 =  bid;
                                                                }
                                                                else{
                                                                    float ask = 0.0;
                                                                    if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                                                                        ask = [[dictionary valueForKey:@"askPrice"]floatValue];
                                                                    }
                                                                    else{
                                                                        ask = [[StaticClass retrieveFromUserDefaults:@"BTCUSD"] floatValue]*[[dictionary valueForKey:@"askPrice"]floatValue];
                                                                    }

                                                                    lblPrice2.text = [NSString stringWithFormat:@"%.2f USD",ask];
                                                                    price2 = ask;
                                                                }
                                                            }
                                                        }
                                                        else if ([str isEqualToString:@"Coinspot"]) {
                                                            if ([[dictionary valueForKey:@"status"] isEqualToString:@"ok"]) {
                                                                NSDictionary *price = [dictionary valueForKey:@"prices"];
                                                                for (int i = 0; i<price.count;i++) {
                                                                    NSString *strName = [[price allKeys]objectAtIndex:i];
                                                                    if ([strName isEqualToString:[[StaticClass retrieveFromUserDefaults:@"C_ID"]lowercaseString]]) {
                                                                        NSDictionary *dict = [price valueForKey:[[StaticClass retrieveFromUserDefaults:@"C_ID"] lowercaseString]];
                                                                        if (typeIndex == 1) {
                                                                            lblPrice2.text = [NSString stringWithFormat:@"%.2f USD",[[dict valueForKey:@"bid"]floatValue]];
                                                                            price2 =  [[dict valueForKey:@"bid"]floatValue];
                                                                        }
                                                                        else{
                                                                            lblPrice2.text = [NSString stringWithFormat:@"%.2f USD",[[dict valueForKey:@"ask"]floatValue]];
                                                                            price2 =  [[dict valueForKey:@"ask"]floatValue];
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        else if ([str isEqualToString:@"Bittrex"]) {
                                                            if ([[dictionary valueForKey:@"success"] integerValue] == 1) {
                                                                NSDictionary *result = [dictionary valueForKey:@"result"];
                                                                if (typeIndex == 1) {
                                                                    float bid = 0.0;
                                                                    if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                                                                        bid = [[result valueForKey:@"Bid"]floatValue];
                                                                    }
                                                                    else{
                                                                        bid = [[StaticClass retrieveFromUserDefaults:@"BTCUSD"] floatValue]*[[result valueForKey:@"Bid"]floatValue];
                                                                    }
                                                                    lblPrice2.text = [NSString stringWithFormat:@"%.2f USD",bid];
                                                                    price2 =  bid;
                                                                }
                                                                else{
                                                                    float ask = 0.0;
                                                                    if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                                                                        ask = [[result valueForKey:@"Ask"]floatValue];
                                                                    }
                                                                    else{
                                                                        ask = [[StaticClass retrieveFromUserDefaults:@"BTCUSD"] floatValue]*[[result valueForKey:@"Ask"]floatValue];
                                                                    }
                                                                    
                                                                    lblPrice2.text = [NSString stringWithFormat:@"%.2f USD",ask];
                                                                    price2 = ask;
                                                                }
                                                            }
                                                        }
                                                        else if ([str isEqualToString:@"Hitbtc"]) {
                                                            if (typeIndex == 1) {
                                                                float bid = 0.0;
                                                                if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                                                                    bid = [[dictionary valueForKey:@"bid"]floatValue];
                                                                }
                                                                else{
                                                                    bid = [[StaticClass retrieveFromUserDefaults:@"BTCUSD"] floatValue]*[[dictionary valueForKey:@"bid"]floatValue];
                                                                }
                                                                
                                                                lblPrice2.text = [NSString stringWithFormat:@"%.2f USD",bid];
                                                                price2 =  bid;//[[dictionary valueForKey:@"bid"]floatValue];
                                                            }
                                                            else{
                                                                float ask = 0.0;
                                                                if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                                                                    ask = [[dictionary valueForKey:@"ask"]floatValue];
                                                                }
                                                                else{
                                                                    ask = [[StaticClass retrieveFromUserDefaults:@"BTCUSD"] floatValue]*[[dictionary valueForKey:@"ask"]floatValue];
                                                                }
                                                                
                                                                lblPrice2.text = [NSString stringWithFormat:@"%.2f USD",ask];
                                                                price2 =  ask;//[[dictionary valueForKey:@"ask"]floatValue];
                                                            }
                                                        }
                                                        else if ([str isEqualToString:@"Cryptopia"]) {
                                                            if ([[dictionary valueForKey:@"Success"] boolValue] == true) {
                                                                NSDictionary *data = [dictionary valueForKey:@"Data"];
                                                                if (data != (id)[NSNull null]) {
                                                                    if (typeIndex == 1) {
                                                                        float bid = 0.0;
                                                                        if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                                                                            bid = [[data valueForKey:@"BidPrice"]floatValue];
                                                                            lblPrice2.text = [NSString stringWithFormat:@"%.2f USD",bid];
                                                                            price2 =  bid;//[[dictionary valueForKey:@"bid"]floatValue];
                                                                        }
                                                                        else{
                                                                            bid = [[data valueForKey:@"BidPrice"]floatValue]* [[StaticClass retrieveFromUserDefaults:@"BTCUSD"] floatValue];
                                                                            lblPrice2.text = [NSString stringWithFormat:@"%.2f USD",bid];
                                                                            price2 =  bid;//[[dictionary valueForKey:@"bid"]floatValue];

                                                                        }
                                                                    }
                                                                    else{
                                                                        float ask = 0.0;
                                                                        if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                                                                            ask = [[data valueForKey:@"AskPrice"]floatValue];
                                                                            lblPrice2.text = [NSString stringWithFormat:@"%.2f USD",ask];
                                                                            price2 =  ask;//[[dictionary valueForKey:@"bid"]floatValue];

                                                                        }
                                                                        else{
                                                                            ask = [[data valueForKey:@"AskPrice"]floatValue]* [[StaticClass retrieveFromUserDefaults:@"BTCUSD"] floatValue];
                                                                            lblPrice2.text = [NSString stringWithFormat:@"%.2f USD",ask];
                                                                            price2 =  ask;//[[dictionary valueForKey:@"bid"]floatValue];

                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        else if ([str isEqualToString:@"Liqui"]) {
                                                            NSString *str = @"";
                                                            if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                                                                str = @"btc_usdt";
                                                            }
                                                            else{
                                                                str = [NSString stringWithFormat:@"%@_btc",[[StaticClass retrieveFromUserDefaults:@"C_ID"]lowercaseString]];
                                                            }
                                                            NSDictionary *result = [dictionary valueForKey:str];
                                                            if (typeIndex == 1) {
                                                                float bid = 0.0;
                                                                if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                                                                    bid = [[result valueForKey:@"buy"]floatValue];
                                                                }
                                                                else{
                                                                    bid = [[StaticClass retrieveFromUserDefaults:@"BTCUSD"] floatValue]*[[result valueForKey:@"buy"]floatValue];
                                                                }
                                                                lblPrice2.text = [NSString stringWithFormat:@"%.2f USD",bid];
                                                                price2 =  bid;
                                                            }
                                                            else{
                                                                float ask = 0.0;
                                                                if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                                                                    ask = [[result valueForKey:@"sell"]floatValue];
                                                                }
                                                                else{
                                                                    ask = [[StaticClass retrieveFromUserDefaults:@"BTCUSD"] floatValue]*[[result valueForKey:@"sell"]floatValue];
                                                                }
                                                                lblPrice2.text = [NSString stringWithFormat:@"%.2f USD",ask];
                                                                price2 = ask;
                                                            }
                                                        }
                                                        else if ([str isEqualToString:@"Gdax"]) {
                                                            if (typeIndex == 1) {
                                                                float bid = 0.0;
                                                                bid = [[dictionary valueForKey:@"bid"]floatValue];
                                                                lblPrice2.text = [NSString stringWithFormat:@"%.2f USD",bid];
                                                                price2 =  bid;//[[dictionary valueForKey:@"bid"]floatValue];
                                                            }
                                                            else{
                                                                float ask = 0.0;
                                                                ask = [[dictionary valueForKey:@"ask"]floatValue];
                                                                lblPrice2.text = [NSString stringWithFormat:@"%.2f USD",ask];
                                                                price2 =  ask;//[[dictionary valueForKey:@"bid"]floatValue];
                                                            }
                                                        }
                                                        else if ([str isEqualToString:@"Coinbase"]) {
                                                            if (typeIndex == 1) {
                                                                if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                                                                    lblPrice2.text = [NSString stringWithFormat:@"%.2f USD",[[dictionary valueForKey:@"bid"]floatValue]];
                                                                    price2 =  [[dictionary valueForKey:@"bid"]floatValue];
                                                                }
                                                                else{
                                                                    float bid = [[StaticClass retrieveFromUserDefaults:@"BTCUSD"] floatValue]*[[dictionary valueForKey:@"bid"]floatValue];
                                                                    
                                                                    lblPrice2.text = [NSString stringWithFormat:@"%.2f USD",bid];
                                                                    price2 = bid;
                                                                    
                                                                }
                                                            }
                                                            else{
                                                                if ([[StaticClass retrieveFromUserDefaults:@"C_ID"] isEqualToString:@"BTC"]) {
                                                                    lblPrice2.text = [NSString stringWithFormat:@"%.2f USD",[[dictionary valueForKey:@"ask"]floatValue]];
                                                                    price2 =  [[dictionary valueForKey:@"ask"]floatValue];
                                                                }
                                                                else{
                                                                    float ask = [[StaticClass retrieveFromUserDefaults:@"BTCUSD"] floatValue]*[[dictionary valueForKey:@"ask"]floatValue];
                                                                    
                                                                    lblPrice2.text = [NSString stringWithFormat:@"%.2f USD",ask];
                                                                    price2 = ask;
                                                                }
                                                            }
                                                        }
                                                        else{
                                                            if ([[dictionary valueForKey:@"success"] integerValue] == 1) {
                                                                NSDictionary *result = [dictionary valueForKey:@"result"];
                                                                if (typeIndex == 1) {
                                                                    lblPrice2.text = [NSString stringWithFormat:@"%.2f USD",[[result valueForKey:@"Bid"]floatValue]];
                                                                    price2 =  [[result valueForKey:@"Bid"]floatValue];
                                                                }
                                                                else{
                                                                    lblPrice2.text = [NSString stringWithFormat:@"%.2f USD",[[result valueForKey:@"Ask"]floatValue]];
                                                                    price2 =  [[result valueForKey:@"Ask"]floatValue];
                                                                }
                                                            }
                                                            else{
                                                                if (typeIndex == 1) {
                                                                    lblPrice2.text = [NSString stringWithFormat:@"%.2f USD",[[dictionary valueForKey:@"bid"]floatValue]];
                                                                    price2 =  [[dictionary valueForKey:@"bid"]floatValue];
                                                                }
                                                                else{
                                                                    lblPrice2.text = [NSString stringWithFormat:@"%.2f USD",[[dictionary valueForKey:@"ask"]floatValue]];
                                                                    price2 =  [[dictionary valueForKey:@"ask"]floatValue];
                                                                }
                                                            }
                                                        }
                                                        
                                                        //Diff
                                                        float diff = price2 - price1;
                                                        diff = fabs(diff);
                                                        float percantage = (price2*100)/price1;
                                                        percantage = percantage-100;
                                                        percantage = fabs(percantage);
                                                        if(price1 == 0.0 && price2 == 0.0)
                                                        {
                                                            lblDiff.text = [NSString stringWithFormat:@"Exchanges don't provide data for coin %@",[StaticClass retrieveFromUserDefaults:@"C_ID"]];
                                                        }
                                                        else if(price1 == 0.0)
                                                        {
                                                            lblDiff.text = [NSString stringWithFormat:@"%@ does not provide data for coin %@",[dataArray objectAtIndex:0],[StaticClass retrieveFromUserDefaults:@"C_ID"]];
                                                        }
                                                        else if(price2 == 0.0)
                                                        {
                                                            lblDiff.text = [NSString stringWithFormat:@"%@ does not provide data for coin %@",[dataArray objectAtIndex:1],[StaticClass retrieveFromUserDefaults:@"C_ID"]];
                                                        }

                                                        else{
                                                            lblDiff.text = [NSString stringWithFormat:@"Difference %.2f USD  (%.1f%%)",diff,percantage];
                                                        }
                                                    });
                                                }
                                                else {
                                                    dispatch_async(dispatch_get_main_queue(), ^{
                                                        [MBProgressHUD hideHUDForView:self.view animated:YES];
                                                    });
                                                }
                                            }];
        [uploadTask resume];
    }
}

-(IBAction)btnBackClick:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)getBTCUSD
{
    Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
    if (networkStatus == NotReachable)
    {
        [self.view makeToast:@"Internet connection not available"];
    }
    else
    {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        NSString *strUrl=[NSString stringWithFormat:@"https://min-api.cryptocompare.com/data/price?fsym=BTC&tsyms=BTC,USD,EUR"];
        NSURL *url=[NSURL URLWithString:strUrl];
        
        NSMutableURLRequest *rq = [NSMutableURLRequest requestWithURL:url];
        [rq setHTTPMethod:@"GET"];
        //[rq setHTTPMethod:@"POST"];
        //NSString *postString = [NSString stringWithFormat:@"func=auth;user=%@;pass=%@",txtEmail.text,txtPassword.text];
        //[rq setHTTPBody:[postString dataUsingEncoding:NSUTF8StringEncoding]];
        NSURLSession *session = [NSURLSession sharedSession];
        NSURLSessionDataTask *uploadTask = [session dataTaskWithRequest:rq
                                                      completionHandler:^(NSData *data, NSURLResponse *response, NSError *error)
                                            {
                                                dispatch_async(dispatch_get_main_queue(), ^{
                                                    [MBProgressHUD hideHUDForView:self.view animated:YES];
                                                });
                                                if(!error){
                                                    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                                                    dispatch_async(dispatch_get_main_queue(), ^{
                                                        if (dictionary.count > 0) {
                                                            NSString *str = [NSString stringWithFormat:@"%.2f",[[dictionary valueForKey:@"USD"] floatValue]];
                                                            [StaticClass saveToUserDefaults:str :@"BTCUSD"];
                                                        }
                                                        else{
                                                            [MBProgressHUD hideHUDForView:self.view animated:YES];
                                                        }
                                                    });
                                                }
                                                else {
                                                    dispatch_async(dispatch_get_main_queue(), ^{
                                                        [MBProgressHUD hideHUDForView:self.view animated:YES];
                                                    });
                                                }
                                            }];
        [uploadTask resume];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
