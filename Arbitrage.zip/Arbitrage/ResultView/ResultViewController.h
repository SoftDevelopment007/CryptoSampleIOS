//
//  ResultViewController.h
//  Arbitrage
//
//  Created by Jignesh Patel on 22/02/18.
//  Copyright © 2018 Arbitrage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ResultViewController : UIViewController

@end
