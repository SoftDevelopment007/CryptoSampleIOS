//
//  CustomCell.m
//  SafariKidCanada
//
//  Created by Jignesh Patel on 12/01/18.
//  Copyright © 2018 SafariKidCanada. All rights reserved.
//

#import "CustomCell.h"

@implementation CustomCell
@synthesize btn1,btn2,btn3,btn4;
@synthesize img1,img2,img3,img4;

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
