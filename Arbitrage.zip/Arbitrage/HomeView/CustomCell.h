//
//  CustomCell.h
//  SafariKidCanada
//
//  Created by Jignesh Patel on 12/01/18.
//  Copyright © 2018 SafariKidCanada. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EGOImageView.h"

@interface CustomCell : UITableViewCell
@property (nonatomic,retain) IBOutlet UIButton *btn1,*btn2,*btn3,*btn4;
@property (nonatomic,retain) IBOutlet EGOImageView *img1,*img2,*img3,*img4;
@end
