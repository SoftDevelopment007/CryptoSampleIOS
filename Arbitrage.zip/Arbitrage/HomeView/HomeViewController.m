//
//  HomeViewController.m
//  Arbitrage
//
//  Created by Jignesh Patel on 22/02/18.
//  Copyright © 2018 Arbitrage. All rights reserved.
//

#import "HomeViewController.h"
#import "ResultViewController.h"
#import "CustomCell.h"
#import "Singleton.h"
#import "StaticClass.h"
#import "Reachability.h"
#import "MBProgressHUD.h"
#import "UIView+Toast.h"

static NSInteger x;

@interface HomeViewController ()
{
    IBOutlet UITableView *tableViewObj;
    
    IBOutlet UITextField *txtSearch;
}
@property (nonatomic,retain)NSMutableArray *coinArray,*subCoinArray;
@end

@implementation HomeViewController
@synthesize coinArray,subCoinArray;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
//    for (int i = 0; i<28;i++) {
//        NSString *str = [NSString stringWithFormat:@"%02d.png", i+1];
//        [coinArray addObject:str];
//    }
//    [tableViewObj reloadData];
    [txtSearch addTarget:self action:@selector(searchCoin) forControlEvents:UIControlEventEditingChanged];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self getAllCoin];
}

-(void)getAllCoin
{
    [coinArray removeAllObjects];
    coinArray = [[NSMutableArray alloc]init];
    [subCoinArray removeAllObjects];
    subCoinArray = [[NSMutableArray alloc]init];
    Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
    if (networkStatus == NotReachable)
    {
        [self.view makeToast:@"Internet connection not available"];
    }
    else
    {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];

        //NSString *strUrl=[NSString stringWithFormat:@"https://bittrex.com/api/v1.1/public/getmarkets"];
        NSString *strUrl=[NSString stringWithFormat:@"https://api.coinmarketcap.com/v1/ticker/?limit=100"];
        NSURL *url=[NSURL URLWithString:strUrl];
        
        NSMutableURLRequest *rq = [NSMutableURLRequest requestWithURL:url];
        [rq setHTTPMethod:@"GET"];
        //[rq setHTTPMethod:@"POST"];
        //NSString *postString = [NSString stringWithFormat:@"func=auth;user=%@;pass=%@",txtEmail.text,txtPassword.text];
        //[rq setHTTPBody:[postString dataUsingEncoding:NSUTF8StringEncoding]];
        NSURLSession *session = [NSURLSession sharedSession];
        NSURLSessionDataTask *uploadTask = [session dataTaskWithRequest:rq
                                                      completionHandler:^(NSData *data, NSURLResponse *response, NSError *error)
                                            {
                                                dispatch_async(dispatch_get_main_queue(), ^{
                                                    [MBProgressHUD hideHUDForView:self.view animated:YES];
                                                });
                                                if(!error){
                                                    NSArray *items = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                                                    dispatch_async(dispatch_get_main_queue(), ^{
                                                        if (items.count > 0) {
                                                            for (NSDictionary *d in items) {
                                                                [self.coinArray addObject:d];
                                                                [self.subCoinArray addObject:d];
                                                            }
                                                        }
                                                        [tableViewObj reloadData];
                                                    });
                                                }
                                                else {
                                                    dispatch_async(dispatch_get_main_queue(), ^{
                                                        [MBProgressHUD hideHUDForView:self.view animated:YES];
                                                    });
                                                }
                                            }];
        [uploadTask resume];
    }
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSInteger noOfRecord = coinArray.count;
    NSInteger noOfpage=noOfRecord/4;
    NSInteger fractionPart=noOfRecord%4;
    NSInteger kNumberOfPages;
    if (fractionPart>0) {
        kNumberOfPages = noOfpage+1;
    }
    else {
        kNumberOfPages=noOfpage;
    }
    return kNumberOfPages;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    @try{
        static NSString *temp= @"CustomCell";
        CustomCell *cellheader = (CustomCell *)[tableViewObj dequeueReusableCellWithIdentifier:temp];
        cellheader.showsReorderControl = NO;
        cellheader.selectionStyle = UITableViewCellSelectionStyleNone;
        cellheader.backgroundColor=[UIColor clearColor];
        
        UILongPressGestureRecognizer *longPress1 = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPress:)];
        [cellheader.btn1 addGestureRecognizer:longPress1];
        longPress1.view.tag = indexPath.row;
        
        UILongPressGestureRecognizer *longPress2 = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPress:)];
        [cellheader.btn2 addGestureRecognizer:longPress2];
        longPress2.view.tag = indexPath.row;
        
        UILongPressGestureRecognizer *longPress3 = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPress:)];
        [cellheader.btn3 addGestureRecognizer:longPress3];
        longPress3.view.tag = indexPath.row;
        
        UILongPressGestureRecognizer *longPress4 = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPress:)];
        [cellheader.btn4 addGestureRecognizer:longPress4];
        longPress4.view.tag = indexPath.row;
        
        [cellheader.btn1 addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
        [cellheader.btn2 addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
        [cellheader.btn3 addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
        [cellheader.btn4 addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
        cellheader.btn1.tag = indexPath.row; cellheader.btn2.tag = indexPath.row;
        cellheader.btn3.tag = indexPath.row; cellheader.btn4.tag = indexPath.row;
        cellheader.btn1.hidden = YES;cellheader.btn2.hidden = YES;
        cellheader.btn3.hidden = YES;cellheader.btn4.hidden = YES;
        cellheader.img1.hidden = YES;cellheader.img2.hidden = YES;
        cellheader.img3.hidden = YES;cellheader.img4.hidden = YES;
        cellheader.img1.layer.cornerRadius = 25.0f;cellheader.img1.layer.masksToBounds = YES;
        cellheader.img2.layer.cornerRadius = 25.0f;cellheader.img2.layer.masksToBounds = YES;
        cellheader.img3.layer.cornerRadius = 25.0f;cellheader.img3.layer.masksToBounds = YES;
        cellheader.img4.layer.cornerRadius = 25.0f;cellheader.img4.layer.masksToBounds = YES;
        cellheader.img1.backgroundColor = [UIColor whiteColor];
        cellheader.img2.backgroundColor = [UIColor whiteColor];
        cellheader.img3.backgroundColor = [UIColor whiteColor];
        cellheader.img4.backgroundColor = [UIColor whiteColor];
        x = indexPath.row * 4;
        
        for (int i = 0; i<4; i++) {
            if (x<coinArray.count) {
                switch (i%4) {
                    case 0:
                    {
                        cellheader.btn1.hidden = NO;cellheader.img1.hidden = NO;
                        NSDictionary *tempObj = [coinArray objectAtIndex:x];
                        [cellheader.btn1 setTitle:[tempObj valueForKey:@"name"] forState:UIControlStateNormal];
                        cellheader.img1.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@.png",[tempObj valueForKey:@"symbol"]]];
                        cellheader.btn1.tag = x;
                        x = x+1;
                    }
                        break;
                    case 1:
                    {
                        cellheader.btn2.hidden = NO;cellheader.img2.hidden = NO;
                        NSDictionary *tempObj = [coinArray objectAtIndex:x];
                        [cellheader.btn2 setTitle:[tempObj valueForKey:@"name"] forState:UIControlStateNormal];
                        cellheader.img2.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@.png",[tempObj valueForKey:@"symbol"]]];
                        cellheader.btn2.tag = x;
                        x = x+1;
                    }
                        break;
                    case 2:
                    {
                        cellheader.btn3.hidden = NO;cellheader.img3.hidden = NO;
                        NSDictionary *tempObj = [coinArray objectAtIndex:x];
                        [cellheader.btn3 setTitle:[tempObj valueForKey:@"name"] forState:UIControlStateNormal];
                        cellheader.img3.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@.png",[tempObj valueForKey:@"symbol"]]];
                        cellheader.btn3.tag = x;
                        x = x+1;
                    }
                        break;
                    case 3:
                    {
                        cellheader.btn4.hidden = NO;cellheader.img4.hidden = NO;
                        NSDictionary *tempObj = [coinArray objectAtIndex:x];
                        [cellheader.btn4 setTitle:[tempObj valueForKey:@"name"] forState:UIControlStateNormal];
                        cellheader.img4.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@.png",[tempObj valueForKey:@"symbol"]]];
                        cellheader.btn4.tag = x;
                        x = x+1;
                    }
                        break;
                        
                    default:
                        break;
                }
            }
        }
        return cellheader;
        
    }
    @catch (NSException *exception) {
        
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 100.0f;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
}

-(void)longPress:(id)sender
{
    UIGestureRecognizer *recognizer = (UIGestureRecognizer*) sender;
    NSDictionary *tempObj = [coinArray objectAtIndex:recognizer.view.tag];
    
    NSString *str = [NSString stringWithFormat:@"Would you like to add %@ to your favorite list?",[tempObj valueForKey:@"name"]];
    
    UIAlertController * alert = [UIAlertController
                                 alertControllerWithTitle:@"Favorite"
                                 message:str
                                 preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* yesButton = [UIAlertAction
                                actionWithTitle:@"Yes"
                                style:UIAlertActionStyleDefault
                                handler:^(UIAlertAction * action) {
                                    
                                    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
                                    NSArray *arr = [userDefaults objectForKey:@"FAV"];
                                    NSMutableArray *favArray = [[NSMutableArray alloc]initWithArray:arr];
                                    for (int i = 0; i<favArray.count; i++) {
                                        NSDictionary *shareObj = [favArray objectAtIndex:i];
                                        if ([[tempObj valueForKey:@"symbol"] isEqualToString:[shareObj valueForKey:@"symbol"]]) {
                                            [favArray removeObjectAtIndex:i];
                                        }
                                    }
                                    
                                    NSMutableDictionary *dict = [[NSMutableDictionary alloc]initWithDictionary:tempObj];
                                    [favArray addObject:dict];
                                    [self.view makeToast:@"Favorite added!"];
                                    
                                    NSUserDefaults *userData = [NSUserDefaults standardUserDefaults];
                                    [userData setObject:favArray forKey:@"FAV"];
                                    [userDefaults synchronize];
                                }];
    
    UIAlertAction* noButton = [UIAlertAction
                               actionWithTitle:@"No"
                               style:UIAlertActionStyleDefault
                               handler:^(UIAlertAction * action) {
                                   //Handle no, thanks button
                               }];
    
    [alert addAction:yesButton];
    [alert addAction:noButton];
    [self presentViewController:alert animated:YES completion:nil];
}

-(IBAction)btnClick:(id)sender
{
    NSDictionary *tempObj = [coinArray objectAtIndex:[sender tag]];
    [StaticClass saveToUserDefaults:[tempObj valueForKey:@"symbol"] :@"C_ID"];
    ResultViewController *newView = [self.storyboard instantiateViewControllerWithIdentifier:@"RESULT"];
    //[newView setTypeStr:@"BTC"];
    [self.navigationController pushViewController:newView animated:YES];
}

-(void)searchCoin
{
    [self searchAutocompleteMenu:txtSearch.text];
}

-(void)searchAutocompleteMenu:(NSString *)substring
{
    @try {
        NSString *curString;
        
        [self.coinArray removeAllObjects];
        
        if(![substring isEqualToString:@""] )
        {
            for(NSDictionary *obj in  self.subCoinArray)
            {
                curString = [[obj valueForKey:@"name"] stringByTrimmingCharactersInSet:
                             [NSCharacterSet whitespaceAndNewlineCharacterSet]];
                substring = [substring stringByTrimmingCharactersInSet:
                             [NSCharacterSet whitespaceAndNewlineCharacterSet]];
                
                NSRange substringRange = [curString rangeOfString:substring options:NSCaseInsensitiveSearch];
                if (substringRange.location != NSNotFound){
                    [self.coinArray addObject:obj];
                }
            }
        }
        else {
            for(NSDictionary *obj in  self.subCoinArray){
                [self.coinArray addObject:obj];
            }
        }
        [tableViewObj  reloadData];
    }
    @catch (NSException *exception) {
        
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (BOOL)textFieldShouldClear:(UITextField *)textField
{
    for(NSDictionary *obj in  subCoinArray){
        [coinArray addObject:obj];
    }
    [tableViewObj  reloadData];
    [textField resignFirstResponder];
    return YES;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
