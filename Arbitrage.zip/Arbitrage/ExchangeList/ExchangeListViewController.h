//
//  ExchangeListViewController.h
//  Arbitrage
//
//  Created by Jignesh Patel on 26/02/18.
//  Copyright © 2018 Arbitrage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ExchangeListViewController : UIViewController
@property (nonatomic,retain) NSString *typeStr;
@end
