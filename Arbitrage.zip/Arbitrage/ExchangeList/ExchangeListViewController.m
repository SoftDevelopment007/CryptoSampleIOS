//
//  ExchangeListViewController.m
//  Arbitrage
//
//  Created by Jignesh Patel on 26/02/18.
//  Copyright © 2018 Arbitrage. All rights reserved.
//

#import "ExchangeListViewController.h"
#import "Singleton.h"
#import "StaticClass.h"
#import "Reachability.h"
#import "MBProgressHUD.h"
#import "UIView+Toast.h"


@interface ExchangeListViewController ()
{
    IBOutlet UILabel *lblBitAsk,*lblBitBid,*lblBitVolume;
    IBOutlet UILabel *lblHitAsk,*lblHitBid,*lblHitVolume;
}
@end

@implementation ExchangeListViewController
@synthesize typeStr;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = YES;
    [self setFirstExchangeValue:self.typeStr];
    [self setSecondExchangeValue:self.typeStr];
}

-(void)setFirstExchangeValue:(NSString *)str
{
    Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
    if (networkStatus == NotReachable)
    {
        [self.view makeToast:@"Internet connection not available"];
    }
    else
    {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        //NSString *strUrl=[NSString stringWithFormat:@"https://bittrex.com/api/v1.1/public/getmarketsummary?market=%@-eth",[str lowercaseString]];
        NSString *strUrl=[NSString stringWithFormat:@"https://bittrex.com/api/v1.1/public/getticker?market=USDT-BTC"];
        NSURL *url=[NSURL URLWithString:strUrl];
        
        NSMutableURLRequest *rq = [NSMutableURLRequest requestWithURL:url];
        [rq setHTTPMethod:@"GET"];
        //[rq setHTTPMethod:@"POST"];
        //NSString *postString = [NSString stringWithFormat:@"func=auth;user=%@;pass=%@",txtEmail.text,txtPassword.text];
        //[rq setHTTPBody:[postString dataUsingEncoding:NSUTF8StringEncoding]];
        NSURLSession *session = [NSURLSession sharedSession];
        NSURLSessionDataTask *uploadTask = [session dataTaskWithRequest:rq
                                                      completionHandler:^(NSData *data, NSURLResponse *response, NSError *error)
                                            {
                                                dispatch_async(dispatch_get_main_queue(), ^{
                                                    [MBProgressHUD hideHUDForView:self.view animated:YES];
                                                });
                                                if(!error){
                                                    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                                                    dispatch_async(dispatch_get_main_queue(), ^{
                                                        if ([[dictionary valueForKey:@"success"] boolValue]==true) {
                                                            NSDictionary *data = [dictionary valueForKey:@"result"];
                                                            lblBitBid.text = [NSString stringWithFormat:@"%.2f",[[data valueForKey:@"Ask"]floatValue]];
                                                            lblBitAsk.text = [NSString stringWithFormat:@"%.2f",[[data valueForKey:@"Bid"]floatValue]];
                                                            lblBitVolume.text = [NSString stringWithFormat:@"%.2f",[[data valueForKey:@"Last"]floatValue]];
                                                        }
                                                     });
                                                }
                                                else {
                                                    dispatch_async(dispatch_get_main_queue(), ^{
                                                        [MBProgressHUD hideHUDForView:self.view animated:YES];
                                                    });
                                                }
                                            }];
        [uploadTask resume];
    }
}

-(void)setSecondExchangeValue:(NSString *)str
{
    Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
    if (networkStatus == NotReachable)
    {
        [self.view makeToast:@"Internet connection not available"];
    }
    else
    {
        // [MBProgressHUD showHUDAddedTo:self.view animated:YES];
//        NSString *strUrl=[NSString stringWithFormat:@"https://api.hitbtc.com/api/2/public/ticker/ETH%@",[str uppercaseString]];
        NSString *strUrl=[NSString stringWithFormat:@"https://apiv2.bitcoinaverage.com/exchanges/ticker/hitbtc/BTCUSD"];
        NSURL *url=[NSURL URLWithString:strUrl];
        
        NSMutableURLRequest *rq = [NSMutableURLRequest requestWithURL:url];
        [rq setHTTPMethod:@"GET"];
        //[rq setHTTPMethod:@"POST"];
        //NSString *postString = [NSString stringWithFormat:@"func=auth;user=%@;pass=%@",txtEmail.text,txtPassword.text];
        //[rq setHTTPBody:[postString dataUsingEncoding:NSUTF8StringEncoding]];
        NSURLSession *session = [NSURLSession sharedSession];
        NSURLSessionDataTask *uploadTask = [session dataTaskWithRequest:rq
                                                      completionHandler:^(NSData *data, NSURLResponse *response, NSError *error)
                                            {
                                                dispatch_async(dispatch_get_main_queue(), ^{
                                                    [MBProgressHUD hideHUDForView:self.view animated:YES];
                                                });
                                                if(!error){
                                                    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                                                    dispatch_async(dispatch_get_main_queue(), ^{
                                                        lblHitBid.text = [NSString stringWithFormat:@"%.2f",[[dictionary valueForKey:@"ask"]floatValue]];
                                                        lblHitAsk.text = [NSString stringWithFormat:@"%.2f",[[dictionary valueForKey:@"bid"]floatValue]];
                                                        lblHitVolume.text = [NSString stringWithFormat:@"%.2f",[[dictionary valueForKey:@"last"]floatValue]];
                                                    });
                                                }
                                                else {
                                                    dispatch_async(dispatch_get_main_queue(), ^{
                                                        [MBProgressHUD hideHUDForView:self.view animated:YES];
                                                    });
                                                }
                                            }];
        [uploadTask resume];
    }
}

-(IBAction)btnBackClick:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
