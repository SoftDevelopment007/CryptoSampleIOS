//
//  SignUpViewController
//  BelaStream
//
//  Created by Jignesh Patel on 30/01/18.
//  Copyright © 2018 BelaStream. All rights reserved.
//

#import "SignUpViewController.h"
#import "Singleton.h"
#import "StaticClass.h"
#import "Reachability.h"
#import "MBProgressHUD.h"
#import "UIView+Toast.h"
#import "Base64.h"
#import "HomeViewController.h"

@interface SignUpViewController ()
{
    IBOutlet UIImageView *photoObj;
    IBOutlet UIButton *btnSignUp;

}
@property (nonatomic,retain) IBOutlet UITextField *txtName,*txtEmail,*txtPassword,*txtConfirmPass;
@property (nonatomic,retain) NSData *myImageData;
@property (nonatomic,retain) UIImagePickerController *imagePickerController;

@end

@implementation SignUpViewController
@synthesize txtName,txtEmail,txtPassword,txtConfirmPass;
@synthesize myImageData,imagePickerController;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    btnSignUp.layer.cornerRadius = 20.0f;
    btnSignUp.layer.masksToBounds = YES;
    btnSignUp.imageView.layer.cornerRadius = 7.0f;
    btnSignUp.layer.shadowRadius = 3.5f;
    btnSignUp.layer.shadowColor = [UIColor blackColor].CGColor;
    btnSignUp.layer.shadowOffset = CGSizeMake(0.0f, 5.0f);
    btnSignUp.layer.shadowOpacity = 0.5f;
    btnSignUp.layer.masksToBounds = NO;
    
   // imagePickerController = [[UIImagePickerController alloc] init];
   // imagePickerController.delegate = self;
   // imagePickerController.allowsEditing = YES;

}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = YES;
}

//AddPhoto
-(IBAction)btnAddPhotoClick:(id)sender
{
    if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
    {
        UIAlertController * alert = [UIAlertController
                                     alertControllerWithTitle:@"Select Photo"
                                     message:@"Select Photo from Camera or Library"
                                     preferredStyle:UIAlertControllerStyleAlert];
        
        
        
        UIAlertAction* yesButton = [UIAlertAction
                                    actionWithTitle:@"Capture"
                                    style:UIAlertActionStyleDefault
                                    handler:^(UIAlertAction * action) {
                                        //Handle your yes please button action here
                                        imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
                                        [self presentViewController:imagePickerController animated:YES completion:nil];
                                    }];
        
        UIAlertAction* noButton = [UIAlertAction
                                   actionWithTitle:@"Choose from Library"
                                   style:UIAlertActionStyleDefault
                                   handler:^(UIAlertAction * action) {
                                       //Handle no, thanks button
                                       imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                                       [self presentViewController:imagePickerController animated:YES completion:nil];
                                   }];
        UIAlertAction* cancelButton = [UIAlertAction
                                       actionWithTitle:@"Cancel"
                                       style:UIAlertActionStyleDefault
                                       handler:^(UIAlertAction * action) {
                                           //Handle no, thanks button
                                       }];
        
        [alert addAction:yesButton];
        [alert addAction:noButton];
        [alert addAction:cancelButton];
        
        [self presentViewController:alert animated:YES completion:nil];
    }
    else
    {
        imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        [self presentViewController:imagePickerController animated:YES completion:nil];
    }
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)selectedImage editingInfo:(NSDictionary *)editingInfo {
    
    self.myImageData = UIImagePNGRepresentation(selectedImage);
    photoObj.image = selectedImage;
    [self dismissViewControllerAnimated:YES completion:nil];
}

//////

//----------------------------------------SIGNUP----------------------------------------------------------------//
-(IBAction)btnSignUpClick:(id)sender
{
    [self dismissKeyboard];
    if([[txtName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] isEqualToString:@""]){
        [self.view makeToast:@"Please enter you name"];
    }
    else if([[txtEmail.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] isEqualToString:@""]){
        [self.view makeToast:@"Please enter you email"];
    }
    else if(![self validateEmail:txtEmail.text]){
        [self.view makeToast:@"Please enter valid email"];
    }
    else if([[txtPassword.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] isEqualToString:@""])
        [self.view makeToast:@"Pleaes etner your password"];
    else if([[txtConfirmPass.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] isEqualToString:@""])
        [self.view makeToast:@"Pleaes etner confirm password"];
    else if(![txtConfirmPass.text  isEqualToString:txtPassword.text])
        [self.view makeToast:@"Password and confirm password dont match"];
    else{
        Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
        NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
        if (networkStatus == NotReachable)
        {
            [self.view makeToast:@"Internet connection not available"];
        }
        else
        {
            [Base64 initialize];
            NSString *imgStr = @"";
            if (self.myImageData != nil) {
                imgStr = [Base64 encode:self.myImageData];
            }
            [MBProgressHUD showHUDAddedTo:self.view animated:YES];
            NSString *strUrl=[NSString stringWithFormat:@"%@sign-up.php?",[[Singleton sharedSingleton]getBaseURL]];
            NSURL *url=[NSURL URLWithString:strUrl];
            
            NSMutableURLRequest *rq = [NSMutableURLRequest requestWithURL:url];
            
            //[rq setHTTPMethod:@"GET"];
            [rq setHTTPMethod:@"POST"];
            NSString *postString = [NSString stringWithFormat:@"name=%@&email=%@&pass=%@&image=%@&token=NA&key=2501145CC2D7E19D94EE7A29D8731E03",txtName.text,txtEmail.text,txtPassword.text,imgStr];
            [rq setHTTPBody:[postString dataUsingEncoding:NSUTF8StringEncoding]];
            NSURLSession *session = [NSURLSession sharedSession];
            NSURLSessionDataTask *uploadTask = [session dataTaskWithRequest:rq
                                                          completionHandler:^(NSData *data, NSURLResponse *response, NSError *error)
                                                {
                                                    dispatch_async(dispatch_get_main_queue(), ^{
                                                        [MBProgressHUD hideHUDForView:self.view animated:YES];
                                                    });
                                                    if(!error){
                                                        NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                                                        dispatch_async(dispatch_get_main_queue(), ^{
                                                            if ([[dictionary valueForKey:@"data"] isEqualToString:@"success"]) {
                                                                [self.view makeToast:[dictionary valueForKey:@"msg"] ];
                                                                [self.navigationController popViewControllerAnimated:YES];
                                                            }
                                                            else{
                                                                [MBProgressHUD hideHUDForView:self.view animated:YES];
                                                                [self.view makeToast:[dictionary valueForKey:@"msg"] ];
                                                            }
                                                        });
                                                    }
                                                    else {
                                                        dispatch_async(dispatch_get_main_queue(), ^{
                                                            [MBProgressHUD hideHUDForView:self.view animated:YES];
                                                        });
                                                    }
                                                }];
            [uploadTask resume];
        }
    }
}

-(IBAction)btnBackClick:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)dismissKeyboard
{
    [txtEmail resignFirstResponder]; [txtPassword resignFirstResponder];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

-(BOOL)validateEmail:(NSString *)candidate {
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    
    return [emailTest evaluateWithObject:candidate];
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField
{
    return YES;
}
//////Facebook Social Login Start//////////
-(IBAction)facebookLogin : (id) sender{
    FBSDKLoginManager *login = [[FBSDKLoginManager alloc] init];
    [StaticClass saveToUserDefaults:@"FB" :@"L_TYPE"];
    //  login.loginBehavior=FBSDKLoginBehaviorWeb;
    
    //[login logInWithReadPermissions:@[@"public_profile", @"email", @"user_friends"],fromViewController:self, handler:^(FBSDKLoginManagerLoginResult *result, NSError *error)  <===Deprecated
    //    login.loginBehavior = FBSDKShareDialogModeFeedWeb;
    
    [login logInWithReadPermissions:@[@"public_profile", @"email", @"user_friends"] fromViewController:self handler:^(FBSDKLoginManagerLoginResult *result, NSError *error)
     {
         if (error)
         {
             // Process error
             NSLog(@"error is :%@",error);
         }
         else if (result.isCancelled)
         {
             // Handle cancellations
             NSLog(@"error is :%@",error);
         }
         else
         {
             if ([result.grantedPermissions containsObject:@"email"])
             {
                 //NSString *fbAccessToken = [FBSDKAccessToken currentAccessToken].tokenString;
                 
                 NSLog(@"Login successfull");
                 [self fetchUserInfo];
                 [login logOut];
             }
         }
     }];
    
}

-(void)fetchUserInfo
{
    if ([FBSDKAccessToken currentAccessToken])
    {
        [[[FBSDKGraphRequest alloc] initWithGraphPath:@"me" parameters:@{@"fields": @"id,name,link,first_name, last_name, picture.type(large), email, birthday,friends,gender,age_range,cover"}]
         startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection, id result, NSError *error) {
             if (!error)
             {
                 Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
                 NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
                 if (networkStatus == NotReachable)
                 {
                     [self.view makeToast:@"Internet connection not available"];
                 }
                 else
                 {
                     //                     [Base64 initialize];
                     //                     NSString *imgStr = @"";
                     //                     if (self.myImageData != nil) {
                     //                         imgStr = [Base64 encode:self.myImageData];
                     //                     }
                     [MBProgressHUD showHUDAddedTo:self.view animated:YES];
                     NSString *strUrl=[NSString stringWithFormat:@"%@sign-up.php?",[[Singleton sharedSingleton]getBaseURL]];
                     NSURL *url=[NSURL URLWithString:strUrl];
                     
                     NSMutableURLRequest *rq = [NSMutableURLRequest requestWithURL:url];
                     
                     //[rq setHTTPMethod:@"GET"];
                     [rq setHTTPMethod:@"POST"];
                     NSString *postString = [NSString stringWithFormat:@"name=%@&email=%@&token=NA&fbid=%@&key=2501145CC2D7E19D94EE7A29D8731E03",[result valueForKey:@"name"],[result valueForKey:@"email"],[result valueForKey:@"id"]];
                     [rq setHTTPBody:[postString dataUsingEncoding:NSUTF8StringEncoding]];
                     NSURLSession *session = [NSURLSession sharedSession];
                     NSURLSessionDataTask *uploadTask = [session dataTaskWithRequest:rq
                                                                   completionHandler:^(NSData *data, NSURLResponse *response, NSError *error)
                                                         {
                                                             dispatch_async(dispatch_get_main_queue(), ^{
                                                                 [MBProgressHUD hideHUDForView:self.view animated:YES];
                                                             });
                                                             if(!error){
                                                                 NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                                                                 dispatch_async(dispatch_get_main_queue(), ^{
                                                                     if ([[dictionary valueForKey:@"data"] isEqualToString:@"success"]) {
                                                                         NSDictionary *user_data = [dictionary valueForKey:@"user_data"];
                                                                         [StaticClass saveToUserDefaults:[user_data valueForKey:@"userID"] :@"UID"];
                                                                         [StaticClass saveToUserDefaults:[user_data valueForKey:@"name"] :@"NAME"];
                                                                         
                                                                         HomeViewController *newView = [self.storyboard instantiateViewControllerWithIdentifier:@"HOME"];
                                                                         [self.navigationController pushViewController:newView animated:YES];
                                                                     }
                                                                     else{
                                                                         [MBProgressHUD hideHUDForView:self.view animated:YES];
                                                                         [self.view makeToast:@"Email or Password in wrong"];
                                                                     }
                                                                 });
                                                             }
                                                             else {
                                                                 dispatch_async(dispatch_get_main_queue(), ^{
                                                                     [MBProgressHUD hideHUDForView:self.view animated:YES];
                                                                 });
                                                             }
                                                         }];
                     [uploadTask resume];
                 }
             }
         }];
    }
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];// this will do the trick
    [super touchesBegan:touches withEvent:event];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
