//
//  SignUpViewController
//  BelaStream
//
//  Created by Jignesh Patel on 30/01/18.
//  Copyright © 2018 BelaStream. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <FBSDKCoreKit/FBSDKCoreKit.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>
#import <FBSDKShareKit/FBSDKShareKit.h>

@interface SignUpViewController : UIViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate>


@end

